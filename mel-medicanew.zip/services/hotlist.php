
<?php
include('./../admin/config.php');

  $sql=mysql_query("SELECT produk.* FROM `promo` LEFT JOIN produk on promo.prod_id = produk.prod_id order by promo.prod_id desc ") or die(mysql_error());
  $rows = array();
  while($r = mysql_fetch_assoc($sql)) {
 $rows[] = $r;
}
header('Content-Type: application/json');
 echo json_encode($rows);
?>
