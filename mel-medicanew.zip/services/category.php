 <?php
 include('./../admin/config.php');

   $sql=mysql_query("SELECT * FROM category") or die(mysql_error());
   $rows = array();
   while($r = mysql_fetch_assoc($sql)) {
  $rows[] = $r;
}
 header('Content-Type: application/json');
  echo json_encode($rows);
 ?>
