 <?php
 include('./../admin/config.php');

   $rows = array();
   if(isset($_GET['category'])) {
         $categoryId=$_GET['category'];
          $query = sprintf("SELECT * FROM `produk` LEFT JOIN logo ON produk.logo_id=logo.logo_id where ctg_id='%s'",mysql_real_escape_string($categoryId));
           $sql=mysql_query($query) or die(mysql_error());

           while($r = mysql_fetch_assoc($sql)) {
          $rows[] = $r;
        }
      }else if(isset($_GET['produkId'])){
        $produkId=$_GET['produkId'];
         $query = sprintf("SELECT * FROM produk where prod_id='%s'",mysql_real_escape_string($produkId));
          $sql=mysql_query($query) or die(mysql_error());


          while($r = mysql_fetch_assoc($sql)) {
         $rows[] = $r;
       }
      }
       header('Content-Type: application/json');
  echo json_encode($rows);
 ?>
