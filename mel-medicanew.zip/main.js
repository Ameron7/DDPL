(function () {
    angular.module("application", ['ngAnimate', 'ui.router', 'ui.bootstrap', 'anim-in-out', 'angular-carousel', 'homepage', 'produk','admin'])
            .config(["$stateProvider", "$urlRouterProvider", function ($stateProvider, $urlRouterProvider) {
                    $stateProvider
                            .state("obatpage", {
                                url: "/obatpage",
                                templateUrl: "pages/obatpage/obatpage.html"
                            })
                            .state("detailobatpage", {
                                url: "/detailobat",
                                templateUrl: "pages/obatpage/detailobat.html",
                                controller: "obatDetailController",
                                params: {
                                    dataobat: null
                                }
                            })
                            .state("aboutUs", {
                                url: "/aboutUs",
                                templateUrl: "pages/aboutUs/aboutUs.html"
                            })
                    $urlRouterProvider.when("", "/homepage");
                    $urlRouterProvider.otherwise("/homepage");
                }])
            .controller("obatDetailController", ["$scope", "$stateParams", function ($scope, $stateParams) {
                    $scope.dataobat = $stateParams.dataobat
                }])

}());
angular.bootstrap(document, ["application"]);