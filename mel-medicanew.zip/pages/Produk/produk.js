(function() {
  "use strict";
  angular.module("produk", []).config(["$stateProvider", "$urlRouterProvider", function($stateProvider, $urlRouterProvider) {
      $stateProvider
        .state("category", {
          url: "/category",
          templateUrl: "pages/produk/category.html",
          controller: "CategoryController"
        })
        .state("product-list", {
          url: "/product-list/:type",
          templateUrl: "pages/produk/product-list.html",
          controller: "ProductListController"
        })
        
    }])
    .controller("CategoryController", ["$scope", "CategoryListService", function($scope, CategoryListService) {
      $scope.categoryList;
      CategoryListService.getAllCategory().then(function(res) {
        $scope.categoryList = res.data;
      });
    }])
    .controller("ProductListController", ["$scope", "$stateParams", "ProductService", "$uibModal", function($scope, $stateParams, ProductService, $uibModal) {
      ProductService.getProductList($stateParams.type).then(function(result) {
        $scope.selectedCategory = result.data;
      })

      $scope.clickProduct = function(n) {
          console.info(n)
        var modalInstance = $uibModal.open({
          templateUrl: 'pages/produk/produk.html',
          controller: "ProductController",
          resolve: {
            product: n
          }
        });
      }
    }])
    .controller('ProductController', function(product, $scope) {
      $scope.product = product;
    })
    .service("CategoryListService", ["$http", function($http) {
      this.getAllCategory = function() {
        return $http.get("services/category.php");
      };
    }])
    .service("ProductService", ["$http", "$filter", function($http, $filter) {
      this.getProductList = function(type) {
        return $http.get("services/produk.php", {
          params: {
            category: type
          }
        });
      };
      this.getProduct=function(prodId){
        return $http.get("services/produk.php", {
          params: {
            id: type
          }
        });
      }
    }])

}());
