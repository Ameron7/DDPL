
(function () {
    "use strict";
    angular.module("homepage", []).config(["$stateProvider", "$urlRouterProvider", function ($stateProvider, $urlRouterProvider) {
            $stateProvider
                    .state("homepage", {
                        url: "/homepage",
                        templateUrl: "pages/homepage/homepage.html",
                        controller: "homepageController"
                    })
        }])
            .service("HomepageService", ["$http", function ($http, $scope) {
                    var produkList = [];
                    var hotList = [];
                    function tampilkanData() {
                        produkList = [
                            {
                                image: 'image/we.jpg',
                                text: [''],
                                id: 0
                            },
                            {
                                image: 'image/panda.jpg',
                                text: [''],
                                id: 1,
                                label: ""
                            }
                        ];
                        hotList = [
                            {
                                image: 'image/bear.jpg',
                                text: [''],
                                id: 0
                            },
                            {
                                image: 'image/ice.jpg',
                                text: [''],
                                id: 1,
                                label: ""
                            }
                        ];
                    }
                    tampilkanData();
                    function tambahDataProduk(produk) {
                        produk.id = produkList.length;
                        console.log(produkList);
                        produkList.push(angular.copy(produk));

                    }
                    return {tampilkanData: produkList,
                        hotList: hotList,
                        tambahkanData: tambahDataProduk}
                }])
            .service("BannerListService", ["$http", function ($http) {
                    this.getAllBanner = function () {
                        return $http.get("services/slider.php");
                    };
                }])
            .service("HotlistService", ["$http", function ($http) {
                    this.getHotlist = function () {
                        return $http.get("services/hotlist.php");
                    };
                }])
            .controller("homepageController", ["$scope", "$state", "HomepageService", "BannerListService", "HotlistService", function ($scope, $state, HomepageService, BannerListService, HotlistService) {

                    $scope.slides = HomepageService.tampilkanData;
                    $scope.hotListData;
                    $scope.bannerList = [];
                    BannerListService.getAllBanner().then(function (res) {
                        $scope.bannerList = res.data;
                    });
                    HotlistService.getHotlist().then(function (res) {
                        $scope.hotListData = res.data;
                    });
                }]);

}());