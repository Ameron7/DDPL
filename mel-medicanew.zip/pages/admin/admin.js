(function(){
    "use strict";
    angular.module("admin",[]) 
            .config(["$stateProvider", "$urlRouterProvider", function ($stateProvider, $urlRouterProvider) {
            $stateProvider
                    .state("admin", {
                        url: "/admin",
                        templateUrl: "pages/admin/admin.html",
                        controller:'adminController'
                        
                    })
        }])
            .controller("homeController",['$scope','HomepageService',function($scope,HomepageService){
                    $scope.formData={};
            $scope.addData=function(data){
                console.log(data)
                HomepageService.tambahkanData(data)
            }
        }])
}());