
(function () {
    "use strict";
    angular.module("homepage", []).config(["$stateProvider", "$urlRouterProvider", function ($stateProvider, $urlRouterProvider) {
            $stateProvider
                    .state("homepage", {
                        url: "/homepage",
                        templateUrl: "pages/homepage/homepage.html",
                        controller: "homepageController"
                    })
        }])
            .service("HomepageService", ["$http", function ($http, $scope) {
                    var produkList = [];
                    var hotList = [];
                    function tampilkanData() {
                        produkList = [
                            {
                                image: 'image/we.jpg',
                                text: [''],
                                id: 0
                            },
                            {
                                image: 'image/panda.jpg',
                                text: [''],
                                id: 1
                            }
                        ];
                        hotList = [
                            {
                                image: 'image/bear.jpg',
                                text: [''],
                                id: 0
                            },
                            {
                                image: 'image/ice.jpg',
                                text: [''],
                                id: 1
                            }
                        ];
                    }
                    tampilkanData();
                    function tambahDataProduk(produk) {
                        produk.id = produkList.length;
                        console.log(produkList);
                        produkList.push(angular.copy(produk));

                    }
                    return {tampilkanData: produkList,
                        hotList: hotList,
                        tambahkanData: tambahDataProduk}
                }])
            .controller("homepageController", ["$scope", "$state", "HomepageService", function ($scope, $state, HomepageService) {

                    $scope.slides = HomepageService.tampilkanData;
                    $scope.hotListData = HomepageService.hotList;

                }]);

}());