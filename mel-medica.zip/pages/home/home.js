(function(){
    "use strict";
    angular.module("home",[]) 
            .config(["$stateProvider", "$urlRouterProvider", function ($stateProvider, $urlRouterProvider) {
            $stateProvider
                    .state("home", {
                        url: "/home",
                        templateUrl: "pages/home/home.html",
                        controller:'homeController'
                        
                    })
        }])
            .controller("homeController",['$scope','HomepageService',function($scope,HomepageService){
                    $scope.formData={};
            $scope.addData=function(data){
                console.log(data)
                HomepageService.tambahkanData(data)
            }
        }])
}());